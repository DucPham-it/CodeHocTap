/*
    String là 1 mảng các kí tự
    Trong chuỗi luôn có kí  tự kết thúc là '\0'(NULL) nên khi khai báo string ta phải cộng thêm 1 vào độ rộng so với array
    Xử lí nhập dữ liệu nhập chuỗi chưa cả khoảng trắng: 
        get.line(<biến string>, <độ dài>, <kí tự kết thucs đọc>);
    Kí  tự NULL cần được để đúng vị trí cần thiết để tránh lỗi
*/
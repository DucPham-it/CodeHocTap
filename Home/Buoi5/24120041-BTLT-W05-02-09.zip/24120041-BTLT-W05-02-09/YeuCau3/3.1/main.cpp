/*
Các ngôn ngữ lập trình có kiểu kí tự (character) chứa các kí tự như 'a','B','1',' ','!',... 
Trong C/C++ kiểu kí tự là char và gán kí tự trong cặp nhảy đơn ' '
Một số kí tự đặc biệt:
    '\n' : xuống dòng
    '\t' : tab ~ 4 khoảng trắng
    '\\' : hiện dấu \
    '\'' : hiện dấu '
    '/'  : hiện dấu /
*/
/*
    Bảng mã ASCII là bảng mã gồm 128 kí tự (0-->127) với mỗi kí tự có một mã số riêng
    Ứng dụng trong truyền thông tin,...
    Trong môn học CSLT học về cách so sánh hoa thường số:
        Các kí tự từ A-->Z, a-->z và 0-->9 là liên tục
        Mã số kí tự thường và hoa là khác nhau
        Các ngôn ngữ lập trình so sánh giá trị thông qua mã số của mã ASCII

*/
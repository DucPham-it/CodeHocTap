#include "functionP06.h"

int main()
{
    Student Num1;
    Input(Num1);
    Output(Num1);
    
    return 0;
}
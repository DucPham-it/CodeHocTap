// ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠤⠒⠈⠉⠉⠉⠉⠒⠀⠀⠤⣀⠀⠀⠀⠀
// ⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⠁⠀⠀⠀⠀⠀⠀⢀⣄⠀⠀⠀⠀⠑⡄⠀⠀
// ⠀⠀⠀⠀⠀⠀⠀⠀⠰⠿⠿⠿⠣⣶⣿⡏⣶⣿⣿⠷⠶⠆⠀⠀⠘⠀
// ⠀⠀⠀⠀⠀⠀⠠⠴⡅⠀⠀⠠⢶⣿⣿⣷⡄⣀⡀⡀⠀⠀⠀⠀⠀⡇⠀
// ⠀⣰⡶⣦⠀⠀⠀⡰⠀⠀⠸⠟⢸⣿⣿⣷⡆⠢⣉⢀⠀⠀⠀⠀⠀⠀⠀⠀
// ⠀⢹⣧⣿⣇⠀⠀⡇⠀⢠⣷⣲⣺⣿⣿⣇⠤⣤⣿⣿⠀⢸⠀⣤⣶⠦⠀⠀
// ⠀⠀⠙⢿⣿⣦⡀⢇⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⡜⣾⣿⡃⠇⢀⣤⡀⠀
// ⠀⠀⠀⠀⠙⢿⣿⣮⡆⠀⠙⠿⣿⣿⣾⣿⡿⡿⠋⢀⠞⢀⣿⣿⣿⣿⣿⡟⠁
// ⠀⠀⠀⠀⠀⠀⠛⢿⠇⣶⣤⣄⢀⣰⣷⣶⣿⠁⡰⢃⣴⣿⡿⢋⠏⠉⠁⠀⠀⠀
// ⠀⠀⠀⠀⠀⠀⠀⠠⢾⣿⣿⣿⣞⠿⣿⣿⢿⢸⣷⣌⠛⠋⠀⠘⠀⠀⠀⠀
// ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠙⣿⣿⣿⣶⣶⣿⣯⣿⣿⣿⣆⠀⠇
// TRY TO FIX BUG TODAY, BECOME A NICE CODER TOMORROW !!!


//24120041 - Pham Vo Duc

#include <iostream>
using namespace std;    

void merge ( int arr1 [] , int n1 , int arr2 [] , int n2 , int result []) ;

int main(){
    int arr1 [] = {1 , 3 , 5 , 7 , 9};
    int n1 = sizeof ( arr1 ) / sizeof ( arr1 [0]) ;

    int arr2 [] = {2 , 4 , 6 , 8 , 10};
    int n2 = sizeof ( arr2 ) / sizeof ( arr2 [0]) ;

    int result [ n1 + n2 ];

    merge ( arr1 , n1 , arr2 , n2 , result ) ;

    cout << " Merged array : ";
    for (int i = 0; i < n1+n2; i++)
    {
        cout << result[i] << " ";
    }
    cout << endl;    

    return 0;
}

void merge ( int arr1 [] , int n1 , int arr2 [] , int n2 , int result []) {
    int i = 0, j = 0, k = 0;
    while (i < n1 && j < n2) {
        if (arr1[i] < arr2[j]) {
            result[k] = arr1[i];
            i++;
        } else {
            result[k] = arr2[j];
            j++;
        }
        k++;
    }
    while (i < n1) {
        result[k] = arr1[i];
        i++;
        k++;
    }
    while (j < n2) {
        result[k] = arr2[j];
        j++;
        k++;
    }
}

template <typename Func , typename ... Args >
3 double measureExecutionTime ( Func func , Args &&... args ) {
4 auto start = std :: chrono :: high_resolution_clock :: now () ;
5
6 func ( std :: forward < Args >( args ) ...) ;
7
8 auto end = std :: chrono :: high_resolution_clock :: now () ;
9
10 auto duration =
11 std :: chrono :: duration_cast < std :: chrono :: microseconds >( end - start ) ;
12
13 return duration . count () / 1000.0;
14 }